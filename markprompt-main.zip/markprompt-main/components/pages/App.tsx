import { TeamSettingsLayout } from '../layouts/TeamSettingsLayout';

const AppPage = () => {
  return <TeamSettingsLayout title="Home" />;
};

export default AppPage;
