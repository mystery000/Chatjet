import { TeamSettingsLayout } from '@/components/layouts/TeamSettingsLayout';

const Team = () => {
  return <TeamSettingsLayout title="Team">Coming soon</TeamSettingsLayout>;
};

export default Team;
