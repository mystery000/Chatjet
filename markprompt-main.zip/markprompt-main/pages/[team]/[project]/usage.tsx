import { ProjectSettingsLayout } from '@/components/layouts/ProjectSettingsLayout';

const Usage = () => {
  return <ProjectSettingsLayout title="Usage">asd</ProjectSettingsLayout>;
};

export default Usage;
