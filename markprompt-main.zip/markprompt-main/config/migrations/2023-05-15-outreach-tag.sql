-- Add an outreach tag to the users table
alter table users
add column outreach_tag text;